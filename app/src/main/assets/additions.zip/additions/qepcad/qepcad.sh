installdir="/data/data/jp.yhonda/files"
qe="$installdir/additions/qepcad"
export installdir
export qe
binname="$1"
"$binname" < "$installdir/tmp/qepcad_input.txt" > "$installdir/tmp/qepcad_output.txt"

